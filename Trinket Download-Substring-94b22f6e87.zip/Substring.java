import java.util.*;

public class Substring
{
	    public static void main(String[] args)
	    {

	          String main, maintw, mainsi; 
	          int mainth, mainfo, mainfi;
            Scanner userinput = new Scanner(System.in);
            System.out.print("Enter a long string: ");
            main = userinput.nextLine();
            System.out.print("Enter a substring: ");
            maintw = userinput.nextLine();
            System.out.println("Length of long string: " + (main.length()));
            mainfo = (main.length());
            System.out.println("Length of substring: " + (maintw.length()));
            System.out.println("Start position of substring: " + (main.indexOf(maintw)));
            mainth = (main.indexOf(maintw));
            System.out.println("Before substring was: " + (main.substring(0,(main.indexOf(maintw)))));
            System.out.println("After substring was: " + (main.substring(mainth+maintw.length(),mainfo)));
            
            System.out.print("Enter a position between 0 and " + (main.length() + ": "));
            mainfi = userinput.nextInt();
            System.out.println("Character at position " + mainfi + " : " + (main.charAt(mainfi)));
            userinput.nextLine(); // Collect the left over enter key press
            System.out.print("Enter a replacement string: ");
            mainsi = userinput.nextLine();
            System.out.println("Your new string is: " + main.replace(maintw,mainsi));
            
            
	    }
	    
}