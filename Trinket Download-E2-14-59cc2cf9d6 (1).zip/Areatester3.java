import java.awt.Point;


public class Areatester3 
{
public static void main(String[ ] args)

{
Point box = new Point(3,4);
Point boxa = new Point(-3,-4);
System.out.print("Distance: " +box.distance(boxa));
}
}
