import java.awt.Rectangle;


public class GrowPrinter
{
public static void main(String[ ] args)

{
   int height, width;
Rectangle square = new Rectangle(100,100,50,50);
height = 25;
width = 25;
System.out.println((square));
square.grow(height, width);
square.translate(25,25);
System.out.println((square));

  
}
}